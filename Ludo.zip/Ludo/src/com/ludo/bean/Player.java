package com.ludo.bean;

public class Player {
	String name;
	int currentPosition;
	String status;

	public Player() {
		// TODO Auto-generated constructor stub
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getCurrentPosition() {
		return currentPosition;
	}


	public void setCurrentPosition(int currentPosition) {
		this.currentPosition = currentPosition;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
